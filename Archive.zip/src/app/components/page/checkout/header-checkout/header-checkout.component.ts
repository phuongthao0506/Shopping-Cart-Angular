import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-checkout',
  templateUrl: './header-checkout.component.html',
  styleUrls: ['./header-checkout.component.scss']
})
export class HeaderCheckoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
